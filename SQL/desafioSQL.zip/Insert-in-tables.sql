USE desafio_sql

--insert tipos
INSERT INTO plan_types (name) 
VALUES	('Projeto'), 
		('Programa Evolu��o'), 
		('Processo'), 
		('Iniciativa Estrat�gica'), 
		('Relacionamento & Inova��o')

select * from plan_types
select * from users

--insert status
INSERT INTO plan_status (name) 
VALUES	('Aberto'), 
		('Suspenso'), 
		('Concluido'), 
		('Cancelado'),
		('atrasado')

--insert usuarios
INSERT INTO users (name, last_changed_date)
VALUES	('Joana Santos', GETDATE()),
		('Felipe Alberto', GETDATE()),
		('Carlos Noronha', GETDATE()),
		('Vergilio Afonso', GETDATE()),
		('Joaquina Cirilla', GETDATE()),
		('Thomas Tequila', GETDATE()),
		('Vanessa Panderim', GETDATE())

--insert plans
INSERT INTO plans (name, id_type, id_user, id_status, start_date, end_date, description, cost)
VALUES ('Treinamento - DEV', 39, 100, 1, GETDATE(), '20190412', 'Treinamento da equipe de desenvolviemnto', 250.50),
('Pesquisa de Tecnologias', 48, 105, 4, '20190401', '20190412', 'Pesquisando novas tecnologias', 1350.80),
('Aplicar novo processo', 42, 106, 3, '20190101', '20190212', 'Aplicando novo processo na empresa', 825.30),
('Projeto StartWEB', 36, 103, 1, GETDATE(), '20190831', 'Novo projeto de software WEB', 3500.00),
('Confraterniza��o', 48, 104, 2, '20180501', '20190115', 'Churrasco de entrozamento', 1250.50),
('Plano 1', 48, 102, 1, '20180501', '20190403', 'Super Plano', 1250.50),
('Plano 2', 48, 106, 3, '20180501', '20190803', 'Super Plano', 125.50),
('Plano 3', 48, 102, 1, '20181201', '20190202', 'Super Plano', 2150.00),
('Plano 4', 48, 103, 1, '20180901', '20190403', 'Super Plano', 50.50),
('Plano 5', 48, 106, 3, '20190201', '20190603', 'Super Plano', 120.50),
('Plano 6', 48, 102, 1, '20190501', '20190303', 'Super Plano', 1250.50),
('Plano 7', 48, 102, 3, '20190501', '20190303', 'Super Plano', 1250.00),
('Plano 8', 48, 102, 1, '20190501', '20190505', 'Super Plano', 1250.00),
('Plano 9', 48, 104, 1, '20190501', '20190506', 'Super Plano', 120.00),
('Plano 10', 48, 102, 1, '20190501', '20190506', 'Super Plano', 150.00),
('Plano 11', 48, 104, 1, '20190501', '20190605', 'Super Plano', 250.00),
('Plano 12', 48, 104, 1, '20190501', '20190706', 'Super Plano', 1360.00),
('Plano 13', 48, 104, 1, '20190501', '20190420', 'Super Plano', 6950.00),
('Plano 14', 48, 104, 1, '20190501', '20190425', 'Super Plano', 8950.00),
('Plano 15', 48, 102, 1, '20190501', '20190422', 'Super Plano', 60.00),
('Plano 16', 48, 104, 1, '20190501', '20190423', 'Super Plano', 50.00)


--insert plan_interested
INSERT INTO plan_interested_users (id_plan, id_user)
VALUES	(305, 101), (305, 102), (305, 106),
		(306, 101), (306, 102), (306, 106), (306, 105),
		(307, 101), (307, 105), (307, 103),
		(308, 101), (308, 106), (308, 105), (308, 102),
		(309, 106), (309, 105), (309, 103), (309, 102), (309, 101)
