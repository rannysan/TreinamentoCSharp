--CRIAR TYPE INICIALMENTE
CREATE TYPE Lista_Id as TABLE
(ID INT NOT NULL)


--CRIAR PROCEDURE
ALTER PROCEDURE relatorio_filtro
@LISTA AS Lista_Id READONLY,
@DATA_INICIAL AS DATETIME = '20160101',
@DATA_FINAL AS DATETIME = '20161231'
AS
BEGIN
	DECLARE @interessados VARCHAR(200)

	IF @DATA_INICIAL = '20160101' AND @DATA_FINAL = '20161231'
	BEGIN
		SELECT R.id, R.Nome_Plano, R.Nome_User, R.start_date, R.end_date, S.Interessados
		FROM
		(SELECT A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date
		FROM
		(SELECT P.id, P.name as Nome_Plano, U.name as Nome_User, P.start_date, P.end_date
		FROM plans as P INNER JOIN users as U 
		ON P.id_user = U.id 
		GROUP BY P.id, P.name, U.name, P.start_date, P.end_date) as A INNER JOIN @Lista as L
		ON A.id = L.id
		GROUP BY A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date) as R INNER JOIN
		(SELECT  id_plan, COALESCE((SELECT CAST(name AS VARCHAR(500)) + ', ' AS [text()]
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
			 ON I.id_user = U.id) AS O
		WHERE O.id_plan  = C.id_plan
		ORDER BY id_plan
			FOR XML PATH(''), TYPE).value('.[1]', 'VARCHAR(MAX)'), '') AS Interessados
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
		ON I.id_user = U.id) AS C
		GROUP BY id_plan) as S
		ON S.id_plan = R.id
	END
	ELSE IF  @DATA_INICIAL != '20160101' AND @DATA_FINAL != '20161231'
	BEGIN
		SELECT R.id, R.Nome_Plano, R.Nome_User, R.start_date, R.end_date, S.Interessados
		FROM
		(SELECT A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date
		FROM
		(SELECT P.id, P.name as Nome_Plano, U.name as Nome_User, P.start_date, P.end_date
		FROM plans as P INNER JOIN users as U 
		ON P.id_user = U.id 
		GROUP BY P.id, P.name, U.name, P.start_date, P.end_date) as A INNER JOIN @Lista as L
		ON A.id = L.id
		WHERE A.start_date = @DATA_INICIAL 
		GROUP BY A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date) as R INNER JOIN
		(SELECT  id_plan, COALESCE((SELECT CAST(name AS VARCHAR(500)) + ', ' AS [text()]
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
			 ON I.id_user = U.id) AS O
		WHERE O.id_plan  = C.id_plan
		ORDER BY id_plan
			FOR XML PATH(''), TYPE).value('.[1]', 'VARCHAR(MAX)'), '') AS Interessados
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
		ON I.id_user = U.id) AS C
		GROUP BY id_plan) as S
		ON S.id_plan = R.id
	END

	IF @DATA_INICIAL != '20160101' AND @DATA_FINAL = '20161231'
	BEGIN
		SELECT R.id, R.Nome_Plano, R.Nome_User, R.start_date, R.end_date, S.Interessados
		FROM
		(SELECT A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date
		FROM
		(SELECT P.id, P.name as Nome_Plano, U.name as Nome_User, P.start_date, P.end_date
		FROM plans as P INNER JOIN users as U 
		ON P.id_user = U.id 
		GROUP BY P.id, P.name, U.name, P.start_date, P.end_date) as A INNER JOIN @Lista as L
		ON A.id = L.id
		WHERE A.start_date = @DATA_INICIAL 
		GROUP BY A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date) as R INNER JOIN
		(SELECT  id_plan, COALESCE((SELECT CAST(name AS VARCHAR(500)) + ', ' AS [text()]
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
			 ON I.id_user = U.id) AS O
		WHERE O.id_plan  = C.id_plan
		ORDER BY id_plan
			FOR XML PATH(''), TYPE).value('.[1]', 'VARCHAR(MAX)'), '') AS Interessados
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
		ON I.id_user = U.id) AS C
		GROUP BY id_plan) as S
		ON S.id_plan = R.id
	END

	IF @DATA_INICIAL = '20160101' AND @DATA_FINAL != '20161231'
	BEGIN
		SELECT R.id, R.Nome_Plano, R.Nome_User, R.start_date, R.end_date, S.Interessados
		FROM
		(SELECT A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date
		FROM
		(SELECT P.id, P.name as Nome_Plano, U.name as Nome_User, P.start_date, P.end_date
		FROM plans as P INNER JOIN users as U 
		ON P.id_user = U.id 
		GROUP BY P.id, P.name, U.name, P.start_date, P.end_date) as A INNER JOIN @Lista as L
		ON A.id = L.id
		WHERE A.end_date = @DATA_FINAL
		GROUP BY A.id, A.Nome_Plano, A.Nome_User, A.start_date, A.end_date) as R INNER JOIN
		(SELECT  id_plan, COALESCE((SELECT CAST(name AS VARCHAR(500)) + ', ' AS [text()]
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
			 ON I.id_user = U.id) AS O
		WHERE O.id_plan  = C.id_plan
		ORDER BY id_plan
			FOR XML PATH(''), TYPE).value('.[1]', 'VARCHAR(MAX)'), '') AS Interessados
		FROM (select I.id_plan, I.id_user, U.name from plan_interested_users as I INNER JOIN users as U
		ON I.id_user = U.id) AS C
		GROUP BY id_plan) as S
		ON S.id_plan = R.id
	END

END


--TESTE
DECLARE @Lista AS Lista_Id
INSERT INTO @Lista (ID) 
    VALUES ('309'), ('305'), ('307')

EXEC relatorio_filtro @LISTA = @Lista, @DATA_FINAL = '20190412'


