--exercico 9 Relatorio
--CRIAR TABELA AUXILIAR
CREATE TABLE relatorio_user_plans
    (
     id_user INT NOT NULL,
	 name VARCHAR(50) NOT NULL,
	 count_concluidos INT NULL DEFAULT 0,
	 count_concluidos_atrasados INT NULL DEFAULT 0,
	 count_andamento INT NULL DEFAULT 0,
	 count_cancelados_suspensos INT NULL DEFAULT 0,
    )

--EXECUTAR COMANDOS PARA POPULAR A TABELA AUXILIAR
delete from relatorio_user_plans

DECLARE @status INT
DECLARE @id_user INT
DECLARE @name_user VARCHAR(50)
DECLARE @aux INT
DECLARE @aux_suspenso INT

DECLARE CURSOR3 CURSOR FOR SELECT id
FROM users
OPEN CURSOR3
FETCH NEXT FROM CURSOR3 INTO @id_user
WHILE @@FETCH_STATUS = 0
BEGIN

	SET @name_user = (SELECT name FROM users WHERE id = @id_user)
	INSERT INTO relatorio_user_plans (id_user, name) VALUES (@id_user, @name_user)

	SET @aux_suspenso = 0

	DECLARE CURSOR2 CURSOR FOR SELECT id
	FROM plan_status
	OPEN CURSOR2
	FETCH NEXT FROM CURSOR2 INTO @status
	WHILE @@FETCH_STATUS = 0
	BEGIN

		SET @aux = 0
		SELECT @aux = COUNT(*)
		FROM users as U INNER JOIN plans as P
		ON U.id = P.id_user
		where id_status = @status and u.id = @id_user
		GROUP BY U.id, U.name, P.id_status

		IF @status = 3
		BEGIN 
			
			DECLARE @id_plan INT
			DECLARE @data_conclus�o DATETIME
			DECLARE @end_date DATETIME

			DECLARE CURSOR4 CURSOR FOR SELECT P.id
			FROM users as U INNER JOIN plans as P
			ON U.id = P.id_user
			where id_status = 3 and U.id = @id_user
			GROUP BY U.id, P.id

				OPEN CURSOR4
				FETCH NEXT FROM CURSOR4 INTO @id_plan
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @data_conclus�o = NULL
					SELECT @data_conclus�o = date FROM plans_history WHERE id_plan = @id_plan and id_plan_status = 3
					SELECT @end_date = end_date FROM plans WHERE id = @id_plan
					

					IF DATEDIFF(DAY, @data_conclus�o, @end_date) < 0
					BEGIN
						UPDATE relatorio_user_plans SET count_concluidos_atrasados = @aux WHERE id_user = @id_user
					END
					ELSE
					BEGIN
						UPDATE relatorio_user_plans SET count_concluidos = @aux WHERE id_user = @id_user
					END
				FETCH NEXT FROM CURSOR4 INTO @id_plan
				END
				DEALLOCATE CURSOR4
		END

		IF @status = 2
		BEGIN 
			SET @aux_suspenso = @aux
		END

		IF @status = 1
		BEGIN 
			UPDATE relatorio_user_plans SET count_andamento = @aux WHERE id_user = @id_user
		END

		IF @status = 5
		BEGIN 
			UPDATE relatorio_user_plans SET count_cancelados_suspensos = (@aux + @aux_suspenso) WHERE id_user = @id_user
		END

		--PRINT CONCAT ( @aux, '--', @id_user, '--' , @status )  
		FETCH NEXT FROM CURSOR2 INTO @status
	END
	DEALLOCATE CURSOR2

FETCH NEXT FROM CURSOR3 INTO @id_user
END
DEALLOCATE CURSOR3


--CRIAR VIEW DA TABELA AUXILIAR
ALTER VIEW Relatorio_plans_users
AS
SELECT * FROM relatorio_user_plans

--TESTAR
SELECT * FROM Relatorio_plans_users






