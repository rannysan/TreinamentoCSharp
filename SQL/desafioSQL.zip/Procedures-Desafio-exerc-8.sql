USE desafio_sql

--criar view

CREATE VIEW [dbo].[tabela_atrasados]
AS
SELECT U.id, P.id_status, (CASE 
WHEN id_status = 1 THEN 'Aberto'
WHEN id_status = 2 THEN 'Suspenso'
WHEN id_status = 3 THEN 'Concluido'
WHEN id_status = 4 THEN 'Atrasado'
ELSE 'Cancelado' END
) AS STATUS, COUNT(*) as CONT
FROM
users as U INNER JOIN plans as P
ON U.id = P.id_user
WHERE P.id_status = 4
GROUP BY U.id, P.id_status
GO

--item 8 - procedure
--criar procedure

CREATE PROCEDURE verificar_atrasados
AS
BEGIN
   
	DECLARE @id_usuario INT
	DECLARE @cont_atrasados INT
	DECLARE @data_final DATETIME

	DECLARE CURSOR1 CURSOR FOR SELECT id 
		FROM tabela_atrasados
	OPEN CURSOR1
	FETCH NEXT FROM CURSOR1 INTO @id_usuario
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @cont_atrasados = (select CONT from tabela_atrasados where id = @id_usuario)
	

		IF @cont_atrasados > 1 
		BEGIN
			UPDATE users SET can_create_plan = 0 WHERE id = @id_usuario
		END

		IF @cont_atrasados = 1 
		BEGIN
			SET @data_final = (SELECT end_date FROM plans WHERE id_user = @id_usuario AND id_status = 4)
			IF DATEDIFF(MONTH, @data_final, GETDATE()) > 0
			BEGIN
				UPDATE users SET can_create_plan = 0 WHERE id = @id_usuario
			END
		END
		FETCH NEXT FROM CURSOR1 INTO @id_usuario
	END
	CLOSE CURSOR1
	DEALLOCATE CURSOR1
END

--testando

EXEC verificar_atrasados




