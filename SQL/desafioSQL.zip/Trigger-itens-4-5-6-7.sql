USE desafio_sql

-- triggers - itens 4,5,6 update users

CREATE TRIGGER tg_users_update
ON users
AFTER  UPDATE
AS
BEGIN
--verificar removed
	DECLARE @old_removed BIT
	DECLARE @new_removed BIT
--verificar can_create
	DECLARE @old_create BIT
	DECLARE @new_create BIT
--dados do necess�rios
	DECLARE @inserted_id INT
	DECLARE @can_create BIT

--setando verificadores
	SET @old_create = (SELECT can_create_plan FROM deleted)
	SET @new_create = (SELECT can_create_plan FROM inserted)
	SET @old_removed = (SELECT removed FROM deleted)
	SET @new_removed = (SELECT removed FROM inserted)

--setando dados
	SET @inserted_id = (SELECT id FROM inserted)
	SET @can_create = (SELECT can_create_plan FROM inserted)

--verificando removed
	IF @old_removed <> @new_removed
	BEGIN
		IF @new_removed = 1
		BEGIN
			INSERT INTO users_history (id_user, status, date) VALUES (@inserted_id, 0, GETDATE()) 
		END
		ELSE
		BEGIN
			INSERT INTO users_history (id_user, status, create_new_plan, date) VALUES (@inserted_id, 1, @can_create, GETDATE()) 
		END
	END 

--verificando can_create
	IF @old_create <> @new_create
	BEGIN
		IF @new_create = 0
		BEGIN
			INSERT INTO users_history (id_user, status, create_new_plan, date) VALUES (@inserted_id, 1, 0, GETDATE()) 
		END
		ELSE
		BEGIN
			INSERT INTO users_history (id_user, status, create_new_plan, date) VALUES (@inserted_id, 1, 1, GETDATE()) 
		END
	END 

	--atualizando o las_change
		UPDATE users SET last_changed_date = GETDATE() WHERE id = @inserted_id
END;


select * from users
select * from users_history

update users set can_create_plan = 0 where id = 102

select * from users
select * from users_history




--trigger para plans


CREATE TRIGGER tg_plans_update
ON plans
AFTER  UPDATE
AS
BEGIN
--verificar status
	DECLARE @old_status INT
	DECLARE @new_status INT
	DECLARE @inserted_id INT

	SET @old_status = (SELECT id_status FROM deleted)
	SET @new_status = (SELECT id_status FROM inserted)
	SET @inserted_id = (SELECT id FROM inserted)

	--verificando se status foi alterado
	IF @old_status <> @new_status
	BEGIN
		INSERT INTO plans_history (id_plan, id_plan_status, date) VALUES (@inserted_id, @new_status, GETDATE()) 
	END 
END;

select * from plans
select * from plans_history

update plans set id_status = 2 where id = 306

select * from plans
select * from plans_history