SELECT A.id
FROM
(SELECT U.id, COUNT(*) as CONT
FROM
users as U INNER JOIN plans as P
ON U.id = P.id_user
WHERE P.id_status = 3
GROUP BY U.id) as A
WHERE A.CONT > 5

ALTER FUNCTION ListaNotasCliente() RETURNS TABLE
AS
RETURN	SELECT id_user FROM Relatorio_plans_users WHERE count_concluidos > 5

go


DECLARE @user_id INT

DECLARE CUR_TEST CURSOR FOR select  id_user from  [dbo].[ListaNotasCliente]()
OPEN CUR_TEST
FETCH NEXT FROM CUR_TEST INTO @user_id
WHILE @@FETCH_STATUS = 0
BEGIN

update users set can_create_plan = 0 where id = @user_id

FETCH NEXT FROM CUR_TEST INTO @user_id
END



