
-- Criando o bd
	-- CREATE DATABASE desafio_sql

USE desafio_sql

-- Criando tabelas
 --FOREIGN KEY([CPF]) REFERENCES [CLIENTES] ([CPF])
 --IDENTITY (1,1) AUTO INCREMENTO
	CREATE TABLE plan_types (
		id INT IDENTITY (3,3) NOT NULL,
		name VARCHAR(100) NOT NULL,
		CONSTRAINT pk_plan_types PRIMARY KEY CLUSTERED (id)
	)

	CREATE TABLE plan_status (
		id INT IDENTITY (1,1) NOT NULL,
		name VARCHAR(100) NOT NULL,
		CONSTRAINT pk_plan_status PRIMARY KEY CLUSTERED (id)
	)

	CREATE TABLE users (
		id INT IDENTITY (100,1) NOT NULL,
		name VARCHAR(100) NOT NULL,
		register_date DATETIME DEFAULT GETDATE(),
		last_changed_date DATETIME NOT NULL,
		can_create_plan BIT DEFAULT 1,
		removed BIT DEFAULT 0,
		CONSTRAINT pk_users PRIMARY KEY CLUSTERED (id)
	)

	CREATE TABLE users_history (
		id INT IDENTITY (200, 1),
		id_user INT NOT NULL,
		status BIT,
		create_new_plan BIT,
		date DATETIME NOT NULL,
		CONSTRAINT pk_users_history PRIMARY KEY CLUSTERED (id),
		FOREIGN KEY(id_user) REFERENCES users (id)
	)

	CREATE TABLE plans (
		id INT IDENTITY (300, 1) NOT NULL,
		name VARCHAR(100) NOT NULL,
		id_type INT NOT NULL,
		id_user INT NOT NULL,
		id_status INT DEFAULT 1,
		start_date DATETIME,
		end_date DATETIME,
		description VARCHAR(500),
		cost FLOAT,
		CONSTRAINT pk_plans PRIMARY KEY CLUSTERED (id),
		FOREIGN KEY (id_type) REFERENCES plan_types (id),
		FOREIGN KEY (id_user) REFERENCES users (id),
		FOREIGN KEY (id_status) REFERENCES plan_status (id)
	)

	CREATE TABLE plans_history (
		id INT IDENTITY (400, 1) NOT NULL,
		id_plan INT NOT NULL,
		id_plan_status INT NOT NULL,
		date DATETIME NOT NULL,
		CONSTRAINT pk_plans_history PRIMARY KEY (id),
		FOREIGN KEY (id_plan) REFERENCES plans (id)
	)

	CREATE TABLE plan_interested_users (
		id INT IDENTITY (500, 1) NOT NULL,
		id_plan INT NOT NULL,
		id_user INT nOT NULL,
		CONSTRAINT pk_plans_interested_users PRIMARY KEY CLUSTERED (id),
		FOREIGN KEY (id_plan) REFERENCES plans (id),
		FOREIGN KEY (id_user) REFERENCES users (id),
	)
